<?php
session_start();
// session_destroy();
$con = mysqli_connect("localhost", "root", "", "testing1");

if (mysqli_connect_errno()) {
  echo "
  <script>
    alert('cannotttttt consact to databass');
    window.location.href='mycart.php'; 
   </script>
  ";
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['purchase'])) {
    $query1 = "INSERT INTO `oder_manger1`(`full_name`, `phone_no`, `address`, `pay_mode`) 
      VALUES ('$_POST[full_name]','$_POST[phone_no]','$_POST[address]','$_POST[pay_mode]')";
    if (mysqli_query($con, $query1)) {
      echo "
      <script>
        alert('yess');
        window.location.href='index.php'; 
       </script>
      ";
    }
  } else {
    echo "
          <script>
            alert('sql erorr');
            window.location.href='index.php'; 
           </script>
          ";
  }
}

?>