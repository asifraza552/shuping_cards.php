<?php include("header.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
</head>

<body>

    <div class="container mt-5">

        <div class="row">
            <div class="col-lg-3">
                <form action="menige.php" method="post">
                    <div class="card">
                        <img src="bimg/1.jpg" class="card-img-top">
                        <div class="card-bodyn text-center">
                            <h5 class="card-title">bag (1)</h5>
                            <p class="card-text">price RS : 300</p>
                            <button type="submit" name="add_to_cart" class="btn btn-danger">add to cart</button>
                            <input type="hidden" name="Item_name" value="bag 1">
                            <input type="hidden" name="price" value="300">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3">
                <form action="menige.php" method="post">
                    <div class="card">
                        <img src="bimg/2.jpg" class="card-img-top">
                        <div class="card-bodyn text-center">
                            <h5 class="card-title">bag (2)</h5>
                            <p class="card-text">price RS : 400</p>
                            <button type="submit" name="add_to_cart" class="btn btn-danger">add to cart</button>
                            <input type="hidden" name="Item_name" value="bag 2">
                            <input type="hidden" name="price" value="400">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3">
                <form action="menige.php" method="post">
                    <div class="card">
                        <img src="bimg/3.jpg" class="card-img-top">
                        <div class="card-bodyn text-center">
                            <h5 class="card-title">bag (3)</h5>
                            <p class="card-text">price RS : 500</p>
                            <button type="submit" name="add_to_cart" class="btn btn-danger">add to cart</button>
                            <input type="hidden" name="Item_name" value="bag 3">
                            <input type="hidden" name="price" value="500">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3">
                <form action="menige.php" method="post">
                    <div class="card">
                        <img src="bimg/1.jpg" class="card-img-top">
                        <div class="card-bodyn text-center">
                            <h5 class="card-title">bag (4)</h5>
                            <p class="card-text">price RS : 600</p>
                            <button type="submit" name="add_to_cart" class="btn btn-danger">add to cart</button>
                            <input type="hidden" name="Item_name" value="bag 4">
                            <input type="hidden" name="price" value="600">
                        </div>
                    </div>
                </form>
            </div>

</body>

</html>